#include <linux/types.h>
#include <linux/kernel.h>
#include <linux/delay.h>
#include <linux/init.h>
#include <linux/module.h>
#include <linux/errno.h>
#include <linux/gpio.h>
#include <linux/cdev.h>
#include <linux/device.h>
#include <linux/of.h>
#include <linux/of_address.h>
#include <linux/of_gpio.h>
#include <asm/uaccess.h>
#include <asm/io.h>
#include <linux/platform_device.h>

struct led_driver_data {
	uint32_t nr;
	uint32_t ng;
	uint32_t nb;
	uint32_t nw;
	uint32_t s1;
	uint32_t s2;
	uint32_t s3;
	uint32_t mtk;
	uint32_t wps;
	uint32_t nr_flag;
	uint32_t ng_flag;
	uint32_t nb_flag;
	uint32_t nw_flag;
	uint32_t s1_flag;
	uint32_t s2_flag;
	uint32_t s3_flag;
	uint32_t mtk_flag;
	uint32_t wps_flag;
	struct device *dev;
};
struct led_driver_data *g_data;

#define SPRD_LEDS_OF_DEVICE_ID_NAME "sprd,led_cpe"
#define SPRD_LEDS_SYSFS_GROUP_NAME	"led_cpe"

#define LED_LOGI(fmt, ...)\
	pr_info("[LED] %s:" fmt "", __func__, ##__VA_ARGS__)

#define LED_LOGD(fmt, ...)\
	pr_debug("[LED] %s:" fmt "", __func__, ##__VA_ARGS__)

#define LED_LOGE(fmt, ...)\
	pr_err("[LED] %s:" fmt "", __func__, ##__VA_ARGS__)

static ssize_t nr_show(struct device *dev,
		struct device_attribute *attr, char *buf)
{
	static uint32_t gpio_nr = 0;
	gpio_nr = gpio_get_value(g_data->nr);
	LED_LOGI("get gpio_nr=%d", gpio_nr);
	return sprintf(buf, "%d", gpio_nr);
}

static ssize_t nr_store(struct device *dev,
        struct device_attribute *attr, const char *buf, size_t count)
{
	static uint32_t gpio_nr = 0;
	if (kstrtouint(buf, 10, &gpio_nr) != 0)
        return -EINVAL;
    
    LED_LOGI("set gpio_nr=%d, count=%zu", gpio_nr, count);
    if(gpio_nr == 1) {
    	gpio_set_value(g_data->nr, gpio_nr);
    } else if(gpio_nr == 0){
    	gpio_set_value(g_data->nr, gpio_nr);
    }
    
    return count;
}

static ssize_t ng_show(struct device *dev,
		struct device_attribute *attr, char *buf)
{
	static uint32_t gpio_ng = 0;
	gpio_ng = gpio_get_value(g_data->ng);
	LED_LOGI("get gpio_ng=%d", gpio_ng);
	return sprintf(buf, "%d", gpio_ng);
}

static ssize_t ng_store(struct device *dev,
        struct device_attribute *attr, const char *buf, size_t count)
{
	static uint32_t gpio_ng = 0;
	if (kstrtouint(buf, 10, &gpio_ng) != 0)
        return -EINVAL;
    
    LED_LOGI("set gpio_ng=%d, count=%zu", gpio_ng, count);
    if(gpio_ng == 1) {
    	gpio_set_value(g_data->ng, gpio_ng);
    } else if(gpio_ng == 0){
    	gpio_set_value(g_data->ng, gpio_ng);
    }
    
    return count;
}

static ssize_t nb_show(struct device *dev,
		struct device_attribute *attr, char *buf)
{
	static uint32_t gpio_nb = 0;
	gpio_nb = gpio_get_value(g_data->nb);
	LED_LOGI("get gpio_nb=%d", gpio_nb);
	return sprintf(buf, "%d", gpio_nb);
}

static ssize_t nb_store(struct device *dev,
        struct device_attribute *attr, const char *buf, size_t count)
{
	static uint32_t gpio_nb = 0;
	if (kstrtouint(buf, 10, &gpio_nb) != 0)
        return -EINVAL;
    
    LED_LOGI("set gpio_nb=%d, count=%zu", gpio_nb, count);
    if(gpio_nb == 1) {
    	gpio_set_value(g_data->nb, gpio_nb);
    } else if(gpio_nb == 0){
    	gpio_set_value(g_data->nb, gpio_nb);
    }
    
    return count;
}

static ssize_t nw_show(struct device *dev,
		struct device_attribute *attr, char *buf)
{
	static uint32_t gpio_nw = 0;
	gpio_nw = gpio_get_value(g_data->nw);
	LED_LOGI("get gpio_nw=%d", gpio_nw);
	return sprintf(buf, "%d", gpio_nw);
}

static ssize_t nw_store(struct device *dev,
        struct device_attribute *attr, const char *buf, size_t count)
{
	static uint32_t gpio_nw = 0;
	if (kstrtouint(buf, 10, &gpio_nw) != 0)
        return -EINVAL;
    
    LED_LOGI("set gpio_nw=%d, count=%zu", gpio_nw, count);
    if(gpio_nw == 1) {
    	gpio_set_value(g_data->nw, gpio_nw);
    } else if(gpio_nw == 0){
    	gpio_set_value(g_data->nw, gpio_nw);
    }
    
    return count;
}

static ssize_t signal1_show(struct device *dev,
		struct device_attribute *attr, char *buf)
{
	static uint32_t gpio_s1 = 0;
	gpio_s1 = gpio_get_value(g_data->s1);
	LED_LOGI("get gpio_s1=%d", gpio_s1);
	return sprintf(buf, "%d", gpio_s1);
}

static ssize_t signal1_store(struct device *dev,
        struct device_attribute *attr, const char *buf, size_t count)
{
	static uint32_t gpio_s1 = 0;
	if (kstrtouint(buf, 10, &gpio_s1) != 0)
        return -EINVAL;
    
    LED_LOGI("set gpio_s1=%d, count=%zu", gpio_s1, count);
    if(gpio_s1 == 1) {
    	gpio_set_value(g_data->s1, gpio_s1);
    } else if(gpio_s1 == 0){
    	gpio_set_value(g_data->s1, gpio_s1);
    }
    
    return count;
}

static ssize_t signal2_show(struct device *dev,
		struct device_attribute *attr, char *buf)
{
	static uint32_t gpio_s2 = 0;
	gpio_s2 = gpio_get_value(g_data->s2);
	LED_LOGI("get gpio_s2=%d", gpio_s2);
	return sprintf(buf, "%d", gpio_s2);
}

static ssize_t signal2_store(struct device *dev,
        struct device_attribute *attr, const char *buf, size_t count)
{
	static uint32_t gpio_s2 = 0;
	if (kstrtouint(buf, 20, &gpio_s2) != 0)
        return -EINVAL;
    
    LED_LOGI("set gpio_s2=%d, count=%zu", gpio_s2, count);
    if(gpio_s2 == 1) {
    	gpio_set_value(g_data->s2, gpio_s2);
    } else if(gpio_s2 == 0){
    	gpio_set_value(g_data->s2, gpio_s2);
    }
    
    return count;
}

static ssize_t signal3_show(struct device *dev,
		struct device_attribute *attr, char *buf)
{
    static uint32_t gpio_s3 = 0;
    gpio_s3 = gpio_get_value(g_data->s3);
    LED_LOGI("get gpio_s3=%d", gpio_s3);

    return sprintf(buf, "%d", gpio_s3);
}

static ssize_t signal3_store(struct device *dev,
        struct device_attribute *attr, const char *buf, size_t count)
{
    static uint32_t gpio_s3 = 0;
    if (kstrtouint(buf, 30, &gpio_s3) != 0)
        return -EINVAL;

    LED_LOGI("set gpio_s3=%d, count=%zu", gpio_s3, count);
    if(gpio_s3 == 1) {
        gpio_set_value(g_data->s3, gpio_s3);
    } else if(gpio_s3 == 0){
        gpio_set_value(g_data->s3, gpio_s3);
    }

    return count;
}

static ssize_t mtk_show(struct device *dev,
               struct device_attribute *attr, char *buf)
{
    static uint32_t gpio_mtk = 0;
    gpio_mtk = gpio_get_value(g_data->mtk);
    LED_LOGI("get gpio_mtk=%d", gpio_mtk);

    return sprintf(buf, "%d", gpio_mtk);
}

static ssize_t mtk_store(struct device *dev,
        struct device_attribute *attr, const char *buf, size_t count)
{
    static uint32_t gpio_mtk = 0;
    if (kstrtouint(buf, 30, &gpio_mtk) != 0)
        return -EINVAL;

    LED_LOGI("set gpio_mtk=%d, count=%zu", gpio_mtk, count);
    if(gpio_mtk == 1) {
        gpio_set_value(g_data->mtk, gpio_mtk);
    } else if(gpio_mtk == 0){
        gpio_set_value(g_data->mtk, gpio_mtk);
    }

    return count;
}

static ssize_t wps_show(struct device *dev,
               struct device_attribute *attr, char *buf)
{
    static uint32_t gpio_wps = 0;
    gpio_wps = gpio_get_value(g_data->wps);
    LED_LOGI("get gpio_wps=%d", gpio_wps);

    return sprintf(buf, "%d", gpio_wps);
}

static ssize_t wps_store(struct device *dev,
        struct device_attribute *attr, const char *buf, size_t count)
{
    static uint32_t gpio_wps = 0;
    if (kstrtouint(buf, 30, &gpio_wps) != 0)
        return -EINVAL;

    LED_LOGI("set gpio_wps=%d, count=%zu", gpio_wps, count);
    if(gpio_wps == 1) {
        gpio_set_value(g_data->wps, gpio_wps);
    } else if(gpio_wps == 0){
        gpio_set_value(g_data->wps, gpio_wps);
    }

    return count;
}
static DEVICE_ATTR(gpio_netr, 0664, nr_show, nr_store);
static DEVICE_ATTR(gpio_netg, 0664, ng_show, ng_store);
static DEVICE_ATTR(gpio_netb, 0664, nb_show, nb_store);
static DEVICE_ATTR(gpio_netw, 0664, nw_show, nw_store);
static DEVICE_ATTR(gpio_signal1, 0664, signal1_show, signal1_store);
static DEVICE_ATTR(gpio_signal2, 0664, signal2_show, signal2_store);
static DEVICE_ATTR(gpio_signal3, 0664, signal3_show, signal3_store);
static DEVICE_ATTR(gpio_mtk, 0664, mtk_show, mtk_store);
static DEVICE_ATTR(gpio_wps, 0664, wps_show, wps_store);

static struct attribute *sprd_led_atts[] = {
    /**
     * &dev_attr_drv_irq.attr,
     * &dev_attr_reset.attr,
     */
    &dev_attr_gpio_netr.attr,
    &dev_attr_gpio_netg.attr,
    &dev_attr_gpio_netb.attr,
    &dev_attr_gpio_netw.attr,
    &dev_attr_gpio_signal1.attr,
    &dev_attr_gpio_signal2.attr,
    &dev_attr_gpio_signal3.attr,
    &dev_attr_gpio_mtk.attr,
    &dev_attr_gpio_wps.attr,
    NULL
};
static const struct attribute_group sprd_led_attr_group = {
    .attrs = sprd_led_atts,
};
static const struct attribute_group *sprd_led_attr_groups[] = {
    &sprd_led_attr_group,
    NULL
};

int sprd_leds_sysfs_add_device(struct device *dev)
{
    int ret, i;

    LED_LOGI("Add device attr groups");
    /*Low version kernel NOT support sysfs_create_groups() */
    for (i = 0; sprd_led_attr_groups[i]; i++) {
        ret = sysfs_create_group(&dev->kobj, sprd_led_attr_groups[i]);
        if (ret) {
            while (--i >= 0)
                sysfs_remove_group(&dev->kobj, sprd_led_attr_groups[i]);
            break;
        }
    }

    if (ret) {
        LED_LOGE("Add device attr failed %d", ret);
        return ret;
    }

    ret = sysfs_create_link(NULL, &dev->kobj, "sprd_cpe");
    if (ret)
        LED_LOGE("Create sysfs link error:%d", ret);

    return 0;
}

void sprd_leds_sysfs_remove_device(struct device *dev)
{
    int i;

    LED_LOGI("Remove device attr groups");
    sysfs_remove_link(NULL, "sprd_cpe");
    /*Low version kernel NOT support sysfs_remove_groups() */
    for (i = 0; sprd_led_attr_groups[i]; i++)
        sysfs_remove_group(&dev->kobj, sprd_led_attr_groups[i]);
}

static int sprd_leds_parse_dt(struct led_driver_data *pdata,
		struct device *dev)
{
	struct device_node *dev_node = dev->of_node;
    LED_LOGI("Parse device tree");
    
    if(!dev_node || !pdata) {
    	LED_LOGE("defer!");
    	return -EPROBE_DEFER;
    }

	pdata->nr = of_get_named_gpio_flags(dev_node, "nr-gpios", 0, &pdata->nr_flag);
	if(pdata->nr < 0) {
		LED_LOGE("Read net red gpio fail!");
	}
	pdata->ng = of_get_named_gpio_flags(dev_node, "ng-gpios", 0, &pdata->ng_flag);
	if(pdata->ng < 0) {
		LED_LOGE("Read net green gpio fail!");
	}
	pdata->nb = of_get_named_gpio_flags(dev_node, "nb-gpios", 0, &pdata->nb_flag);
	if(pdata->nb < 0) {
		LED_LOGE("Read net blue gpio fail!");
	}
	pdata->nw = of_get_named_gpio_flags(dev_node, "nw-gpios", 0, &pdata->nw_flag);
	if(pdata->nw < 0) {
		LED_LOGE("Read net white gpio fail!");
	}
	pdata->s1 = of_get_named_gpio_flags(dev_node, "s1-gpios", 0, &pdata->s1_flag);
	if(pdata->s1 < 0) {
		LED_LOGE("Read net signal1 gpio fail!");
	}
	pdata->s2 = of_get_named_gpio_flags(dev_node, "s2-gpios", 0, &pdata->s2_flag);
	if(pdata->s2 < 0) {
		LED_LOGE("Read net signal2 gpio fail!");
	}
	pdata->s3 = of_get_named_gpio_flags(dev_node, "s3-gpios", 0, &pdata->s3_flag);
	if(pdata->s3 < 0) {
		LED_LOGE("Read net signal3 gpio fail!");
	}
    pdata->mtk = of_get_named_gpio_flags(dev_node, "mtk-gpios", 0, &pdata->mtk_flag);
    if(pdata->mtk < 0) {
        LED_LOGE("Read net mtk gpio fail!");
    }
    pdata->wps = of_get_named_gpio_flags(dev_node, "wps-gpios", 0, &pdata->wps_flag);
    if(pdata->wps < 0) {
        LED_LOGE("Read net wps gpio fail!");
    }
    LED_LOGI("Parse device tree exit");
	return 0;
}

static int sprd_leds_gpio_configure(struct led_driver_data *pdata)
{
	int ret = 0;
    LED_LOGI("Parse device tree");
    
    if (gpio_is_valid(pdata->nr)) {
        ret = gpio_request(pdata->nr, "net_red_gpio");
        if (ret) {
            LED_LOGE("%d :gpio request failed",__LINE__);
            goto err_nr_gpio;
        }

        ret = gpio_direction_output(pdata->nr, 0);
        if (ret) {
            LED_LOGE("set_direction for net_red_gpio failed");
            goto err_nr_gpio;
        }
    }

    if (gpio_is_valid(pdata->ng)) {
        ret = gpio_request(pdata->ng, "net_green_gpio");
        if (ret) {
            LED_LOGE("%d :gpio request failed",__LINE__);
            goto err_ng_gpio;
        }

        ret = gpio_direction_output(pdata->ng, 0);
        if (ret) {
            LED_LOGE("set_direction for net_green_gpio failed");
            goto err_ng_gpio;
        }
    }

    if (gpio_is_valid(pdata->nb)) {
        ret = gpio_request(pdata->nb, "net_blue_gpio");
        if (ret) {
            LED_LOGE("%d :gpio request failed",__LINE__);
            goto err_nb_gpio;
        }

        ret = gpio_direction_output(pdata->nb, 0);
        if (ret) {
            LED_LOGE("%d :gpio request failed",__LINE__);
            goto err_nb_gpio;
        }
    }

    if (gpio_is_valid(pdata->nw)) {
        ret = gpio_request(pdata->nw, "net_white_gpio");
        if (ret) {
            LED_LOGE("%d :gpio request failed",__LINE__);
            goto err_nw_gpio;
        }

        ret = gpio_direction_output(pdata->nw, 0);
        if (ret) {
            LED_LOGE("set_direction for net_white_gpio failed");
            goto err_nw_gpio;
        }
    }

	if (gpio_is_valid(pdata->s1)) {
        ret = gpio_request(pdata->s1, "signal1_gpio");
        if (ret) {
            LED_LOGE("%d :gpio request failed",__LINE__);
            goto err_s1_gpio;
        }

        ret = gpio_direction_output(pdata->s1, 0);
        if (ret) {
            LED_LOGE("set_direction for signal1_gpio failed");
            goto err_s1_gpio;
        }
    }

	if (gpio_is_valid(pdata->s2)) {
        ret = gpio_request(pdata->s2, "signal2_gpio");
        if (ret) {
            LED_LOGE("%d :gpio request failed",__LINE__);
            goto err_s2_gpio;
        }

        ret = gpio_direction_output(pdata->s2, 0);
        if (ret) {
            LED_LOGE("set_direction for signal2_gpio failed");
            goto err_s2_gpio;
        }
    }

	if (gpio_is_valid(pdata->s3)) {
        ret = gpio_request(pdata->s3, "signal3_gpio");
        if (ret) {
            LED_LOGE("%d :gpio request failed",__LINE__);
            goto err_s3_gpio;
        }

        ret = gpio_direction_output(pdata->s3, 1);
        if (ret) {
            LED_LOGE("set_direction for signal3_gpio failed");
            goto err_s3_gpio;
        }
    }
    if (gpio_is_valid(pdata->mtk)) {
        ret = gpio_request(pdata->mtk, "mtk_gpio");
        if (ret) {
            LED_LOGE("%d :gpio request failed",__LINE__);
            goto err_mtk_gpio;
        }

        ret = gpio_direction_output(pdata->mtk, 0);
        if (ret) {
            LED_LOGE("set_direction for mtk_gpio failed");
            goto err_mtk_gpio;
        }
    }
    if (gpio_is_valid(pdata->wps)) {
        ret = gpio_request(pdata->wps, "wps_gpio");
        if (ret) {
            LED_LOGE("%d :gpio request failed",__LINE__);
            goto err_wps_gpio;
        }

        ret = gpio_direction_output(pdata->wps, 0);
        if (ret) {
            LED_LOGE("set_direction for wps_gpio failed");
            goto err_wps_gpio;
        }
    }
    LED_LOGI("exit and led gpio init success!");
	return 0;
err_s3_gpio:
	if (gpio_is_valid(pdata->s3))
		gpio_free(pdata->s3);
err_s2_gpio:
	if (gpio_is_valid(pdata->s2))
		gpio_free(pdata->s2);
err_s1_gpio:
	if (gpio_is_valid(pdata->s1))
		gpio_free(pdata->s1);
err_nw_gpio:
	if (gpio_is_valid(pdata->nw))
		gpio_free(pdata->nw);
err_nb_gpio:
	if (gpio_is_valid(pdata->nb))
		gpio_free(pdata->nb);
err_ng_gpio:
	if (gpio_is_valid(pdata->ng))
		gpio_free(pdata->ng);
err_nr_gpio:
	if (gpio_is_valid(pdata->nr))
		gpio_free(pdata->nr);
err_mtk_gpio:
	if (gpio_is_valid(pdata->mtk))
		gpio_free(pdata->mtk);
err_wps_gpio:
	if (gpio_is_valid(pdata->wps))
		gpio_free(pdata->wps);

	LED_LOGI("exit and led gpio init fail!");
	return ret;
}

static int sprd_leds_probe(struct platform_device *pdev) 
{
	int ret = 0;

	struct led_driver_data *leds_data;

	LED_LOGI("entry!");
    leds_data = devm_kzalloc(&pdev->dev, sizeof(struct led_driver_data), GFP_KERNEL);
    if (!leds_data) {
        LED_LOGE("allocate memory for platform_data fail");
        return -ENOMEM;
    }

	ret = sprd_leds_parse_dt(leds_data, &pdev->dev);
	if(ret < 0) {
		LED_LOGE("parse dts fail!");
		goto err_free_resource;
	}
	
	dev_set_drvdata(&pdev->dev, leds_data);
	g_data = leds_data;

    ret = sprd_leds_gpio_configure(leds_data);
    if (ret) {
        LED_LOGE("configure the gpios fail");
        goto err_free_resource;
    }

	ret = sprd_leds_sysfs_add_device(&pdev->dev);
	if(ret < 0) {
		LED_LOGE("add sysfs device fail!");
		goto err_free_resource;
	}
	LED_LOGI("exit!");
	return 0;
err_free_resource:
	devm_kfree(&pdev->dev, leds_data);
	LED_LOGI("probe failed %d",ret);
	return ret;
}

static int sprd_leds_remove(struct platform_device *pdev) 
{
	struct led_driver_data *leds_data = platform_get_drvdata(pdev);
	
	LED_LOGI("entry!");
	if(leds_data) {
		sprd_leds_sysfs_remove_device(&pdev->dev);
		devm_kfree(&pdev->dev, leds_data);
	}
	platform_set_drvdata(pdev, NULL);
	LED_LOGI("exit!");
	return 0;
}

static const struct of_device_id sprd_leds_dt_match[] = {
	{.compatible = SPRD_LEDS_OF_DEVICE_ID_NAME, },
    { },
};
MODULE_DEVICE_TABLE(of, sprd_leds_dt_match);
static struct platform_driver sprd_leds_driver = {
	.probe	= sprd_leds_probe,
	.remove	= sprd_leds_remove,
	.driver	= {
		.name = SPRD_LEDS_SYSFS_GROUP_NAME,
		.of_match_table = sprd_leds_dt_match,
	},
};

static int __init led_init(void)
{
	return platform_driver_register(&sprd_leds_driver);
}

static void __exit led_exit(void)
{
	return platform_driver_unregister(&sprd_leds_driver);
}

module_init(led_init);
module_exit(led_exit);
MODULE_LICENSE("GPL");
